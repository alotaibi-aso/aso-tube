#!/bin/zsh
set -e
cd "$(dirname "$0")/.."
python3 -I pipeline/fetch_reddit_videos.py
python3 -I pipeline/build_data.py
rm -f site/cfa-tube-data.zip
zip -qr site/cfa-tube-data.zip data/raw pipeline site/videos.json -x '*.DS_Store' '*__pycache__*'
ls -lh site/videos.json site/cfa-tube-data.zip
