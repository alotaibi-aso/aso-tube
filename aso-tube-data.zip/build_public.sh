#!/bin/zsh
set -e
cd "$(dirname "$0")/.."
[ -n "$YOUTUBE_API_KEY" ] && python3 -I pipeline/yt_api.py reddit || python3 -I pipeline/fetch_reddit_videos.py
python3 -I pipeline/build_data.py --public
rm -f public/aso-tube-data.zip
zip -qj public/aso-tube-data.zip public/videos.json pipeline/*.py pipeline/*.sh pipeline/*.json
ls -lh public/
