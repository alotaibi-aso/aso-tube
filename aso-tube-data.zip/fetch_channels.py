import json, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "data" / "raw" / "channels"
OUT.mkdir(parents=True, exist_ok=True)
PL_KEEP = re.compile(r"canslim|can slim|breadth|cycle|momentum|technical|chart|swing|breakout|stage|minervini|o.?neil|ibd|trend|hurst|relative strength|cfa|level|ethic|quant|econom|financial (statement|reporting)|fsa|corporate|equity|fixed income|bond|derivativ|option|futures|swap|alternative|portfolio|wealth|valuation|risk|private|mock|exam|formula|essay|frm", re.I)


def ytdlp(url):
    p = subprocess.run(["yt-dlp", "--flat-playlist", "-J", "--no-warnings", "--extractor-args", "youtubetab:approximate_date", url],
                       capture_output=True, text=True, timeout=1800)
    if p.returncode != 0 or not p.stdout.strip():
        print(f"  fail {url}: {p.stderr.strip()[-200:]}", flush=True)
        return None
    return json.loads(p.stdout)


def slim(e):
    return {k: e.get(k) for k in ("id", "title", "duration", "view_count", "timestamp", "upload_date", "live_status") if e.get(k) is not None}


def fetch(ch):
    dest = OUT / f"{ch['id']}.json"
    if dest.exists() and "--force" not in sys.argv:
        return
    base = f"https://www.youtube.com/channel/{ch['id']}"
    vids = ytdlp(f"{base}/videos")
    if not vids:
        return
    meta = {k: vids.get(k) for k in ("channel", "channel_id", "channel_follower_count", "uploader_id", "description")}
    videos = [slim(e) for e in vids.get("entries") or [] if e.get("id")]
    streams = ytdlp(f"{base}/streams") or {}
    videos += [slim(e) for e in streams.get("entries") or [] if e.get("id")]
    pls = ytdlp(f"{base}/playlists") or {}
    playlists = []
    cands = [e for e in pls.get("entries") or [] if e.get("id")]
    cands = [e for e in cands if ch["scope"] == "cfa" or PL_KEEP.search(e.get("title") or "")][:250]
    for e in cands:
        d = ytdlp(f"https://www.youtube.com/playlist?list={e['id']}")
        if d:
            playlists.append({"id": e["id"], "title": d.get("title") or e.get("title"),
                              "videos": [slim(x) for x in d.get("entries") or [] if x.get("id")]})
    dest.write_text(json.dumps({**meta, **ch, "videos": videos, "playlists": playlists}))
    print(f"{ch['name']}: {len(videos)} videos, {len(playlists)} playlists", flush=True)


chans = json.loads((ROOT / "pipeline" / "channels.json").read_text())
if "--scope" in sys.argv:
    chans = [c for c in chans if c["scope"] == sys.argv[sys.argv.index("--scope") + 1]]
with ThreadPoolExecutor(6) as ex:
    list(ex.map(fetch, chans))
print("DONE", flush=True)
