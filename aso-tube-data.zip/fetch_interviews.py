import json, subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "data" / "raw" / "interviews_search.jsonl"
FIGS = json.loads((ROOT / "pipeline" / "figures.json").read_text())
FMT = "%(.{id,title,channel,channel_id,duration,view_count})j"


def search(fig):
    name = fig[0]
    rows = []
    for q in (f"{name} interview", f"{name} full interview conversation"):
        p = subprocess.run(["yt-dlp", f"ytsearch40:{q}", "--flat-playlist", "--no-warnings", "--print", FMT],
                           capture_output=True, text=True, timeout=600)
        rows += [{**json.loads(l), "figure": name} for l in p.stdout.splitlines() if l.startswith("{")]
    print(f"{name}: {len(rows)}", flush=True)
    return rows


with ThreadPoolExecutor(4) as ex, OUT.open("w") as f:
    for rows in ex.map(search, FIGS):
        for r in rows:
            f.write(json.dumps(r) + "\n")
print("DONE", flush=True)
