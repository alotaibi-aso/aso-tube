import json, subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
OUT = RAW / "reddit_videos_meta.jsonl"

known = set()
for f in (RAW / "channels").glob("*.json"):
    d = json.loads(f.read_text())
    known |= {v["id"] for v in d["videos"]}
    for p in d["playlists"]:
        known |= {v["id"] for v in p["videos"]}
done = set()
if OUT.exists():
    done = {json.loads(l)["id"] for l in OUT.open() if l.strip()}
done |= {l.strip() for l in (RAW / "reddit_videos_failed.txt").open()} if (RAW / "reddit_videos_failed.txt").exists() else set()

want = set()
for f in RAW.glob("reddit_*_*_*.jsonl"):
    for line in f.open():
        want |= set(json.loads(line)["videos"])
todo = sorted(want - known - done)
print(f"reddit videos {len(want)}, already in channels {len(want & known)}, to fetch {len(todo)}", flush=True)

FMT = "%(.{id,title,channel,channel_id,uploader_id,duration,view_count,timestamp,channel_follower_count,availability})j"


def batch(ids):
    p = subprocess.run(["yt-dlp", "--skip-download", "--no-warnings", "--ignore-errors", "--print", FMT,
                        *[f"https://www.youtube.com/watch?v={i}" for i in ids]], capture_output=True, text=True, timeout=3600)
    rows = [json.loads(l) for l in p.stdout.splitlines() if l.startswith("{")]
    return rows, set(ids) - {r["id"] for r in rows}


chunks = [todo[i:i + 25] for i in range(0, len(todo), 25)]
n = 0
with OUT.open("a") as out, (RAW / "reddit_videos_failed.txt").open("a") as bad, ThreadPoolExecutor(6) as ex:
    for rows, failed in ex.map(batch, chunks):
        for r in rows:
            out.write(json.dumps(r) + "\n")
        for i in failed:
            bad.write(i + "\n")
        n += len(rows)
        out.flush()
        print(f"  fetched {n}/{len(todo)}", flush=True)
print("DONE", flush=True)
