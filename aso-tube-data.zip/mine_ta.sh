#!/bin/zsh
cd "$(dirname "$0")/.."
for sub in CANSLIM technicalanalysis swingtrading; do
  for kind_field in "comments body"; do
    for term in youtube youtu.be; do
      python3 -I pipeline/mine_reddit.py $sub ${=kind_field} $term
    done
  done
done
echo TADONE
