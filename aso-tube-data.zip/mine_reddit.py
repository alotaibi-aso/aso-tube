import json, re, sys, time, urllib.error, urllib.request, urllib.parse
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)
API = "https://arctic-shift.photon-reddit.com/api"
YT = re.compile(r"(?:youtube\.com/(?:watch\?(?:[^\s\)\]]*&)?v=|embed/|shorts/|live/|v/)|youtu\.be/)([A-Za-z0-9_-]{11})")
PL = re.compile(r"youtube\.com/(?:playlist\?|watch\?[^\s\)\]]*&)list=([A-Za-z0-9_-]{13,64})")
CH = re.compile(r"youtube\.com/(?:(@[A-Za-z0-9_.-]{3,40})|channel/(UC[A-Za-z0-9_-]{22})|c/([A-Za-z0-9_.-]{2,60})|user/([A-Za-z0-9_.-]{2,60}))")
MIN_SPAN = 2 * 86400


def get(url):
    """Returns rows, or None when the server times out on this window (caller splits it)."""
    for i in range(8):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "cfa-tube-research/0.1"}), timeout=90) as r:
                d = json.load(r)
            return d["data"]
        except urllib.error.HTTPError as e:
            if e.code == 422:
                if i >= 1:
                    return None
                time.sleep(5)
            else:
                time.sleep(15 * (i + 1))
        except Exception:
            time.sleep(10 * (i + 1))
    return None


def extract(text):
    text = text or ""
    return (sorted(set(YT.findall(text))), sorted(set(PL.findall(text))),
            sorted({next(g for g in m if g) for m in CH.findall(text)}))


def ts(s):
    return int(datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())


class Miner:
    def __init__(self, sub, kind, field, term, out):
        self.sub, self.kind, self.field, self.term = sub, kind, field, term
        self.fields = "id,body,created_utc,author,score,link_id" if kind == "comments" else "id,title,selftext,url,created_utc,author,score,num_comments,permalink"
        self.seen = {json.loads(l)["id"] for l in out.open() if l.strip()} if out.exists() else set()
        self.f = out.open("a")
        self.n = 0

    def window(self, a, b):
        before = b
        while True:
            q = urllib.parse.urlencode({"subreddit": self.sub, self.field: self.term, "after": a, "before": before, "limit": 100, "fields": self.fields})
            data = get(f"{API}/{self.kind}/search?{q}")
            if data is None:
                if before - a <= MIN_SPAN:
                    print(f"FAILED {self.kind} {self.term} {a}..{before}", flush=True)
                    return
                mid = (a + before) // 2
                self.window(mid, before)
                self.window(a, mid)
                return
            for r in data:
                if r["id"] in self.seen:
                    continue
                self.seen.add(r["id"])
                text = r.get("body") or " ".join(filter(None, [r.get("title"), r.get("selftext"), r.get("url")]))
                vids, pls, chs = extract(text)
                if vids or pls or chs:
                    self.n += 1
                    self.f.write(json.dumps({"sub": self.sub, "kind": self.kind, "id": r["id"], "author": r.get("author"),
                                             "score": r.get("score"), "ts": r.get("created_utc"), "link_id": r.get("link_id"),
                                             "permalink": r.get("permalink"), "text": text[:1500],
                                             "videos": vids, "playlists": pls, "channels": chs}) + "\n")
            self.f.flush()
            if len(data) < 100:
                return
            before = int(min(r["created_utc"] for r in data))
            time.sleep(1.5)


if __name__ == "__main__":
    sub, kind, field, term = sys.argv[1:5]
    years = [int(y) for y in sys.argv[5].split(",")] if len(sys.argv) > 5 else range(2014, datetime.now(timezone.utc).year + 1)
    safe = re.sub(r"\W+", "_", term)
    m = Miner(sub, kind, field, term, OUT / f"reddit_{sub}_{kind}_{safe}.jsonl")
    for y in years:
        m.window(ts(f"{y}-01-01"), min(ts(f"{y + 1}-01-01"), int(time.time())))
        print(f"{sub} {kind} {field}={term} {y}: +{m.n} new so far", flush=True)
        time.sleep(1.5)
    print(f"DONE {sub} {kind} {term}: {m.n} new", flush=True)
