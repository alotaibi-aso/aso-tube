#!/bin/zsh
cd "$(dirname "$0")/.."
python3 -I pipeline/mine_reddit.py CFA comments body youtube 2024,2025,2026
python3 -I pipeline/mine_reddit.py CFA comments body youtu.be 2018,2019,2020,2021,2022,2023,2024,2025,2026
python3 -I pipeline/mine_reddit.py CFA posts query youtube
python3 -I pipeline/mine_reddit.py CFA posts query youtu.be
python3 -I pipeline/mine_reddit.py CFA comments body youtube 2014,2015,2016,2017,2018,2019,2020,2021,2022,2023
echo ALLDONE
